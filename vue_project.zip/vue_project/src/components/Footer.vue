<script setup>
import { Icon } from '@iconify/vue';
</script>


<template>
    <footer class=" bg-white py-10 border border-r-0 border-l-0 border-b-0">
      <div>
        <ul class="flex justify-between items-center gap-8 px-12">
           <div class="Row-icon flex gap-5">
                    
            <div class="Row-icon flex gap-5">
  <ul class="flex gap-4">
    <li class="flex items-center gap-2">
      <Icon class="size-[30px]" size-8 icon="logos:facebook" />
    </li>
    <li class="flex items-center gap-2">
      <Icon class="size-[30px]" icon="logos:telegram" />
    </li>
    <li class="flex items-center gap-2">
      <Icon class="size-[30px]" icon="skill-icons:instagram" />
    </li>
    <li class="flex items-center gap-2">
      <Icon class="size-[30px]" icon="logos:twitter" />
    </li>
    <li class="flex items-center gap-2">
      <Icon class="size-[30px]" icon="logos:youtube-icon" />
    </li>
    <li class="flex items-center gap-2">
      <Icon class="size-[30px]" icon="twemoji:flag-cambodia" />
    </li>
  </ul>
</div>


           </div>
           
           <div class="Row-title flex gap-5">
                  <li class="flex items-center gap-2">
                  <a href="">ជជែកផ្ទាល់</a>
                </li>
                <li class="flex items-center gap-2">
                  <a href="">ទំនាក់ទំនង</a>
                </li>
                <li class="flex items-center gap-2">
                  <a href="">ផ្តល់មតិយោបល់</a>
                </li>
                <li class="flex items-center gap-2">
                  <a href="">សំនួរ និងចម្លើយ</a>
                </li>
           </div>
        </ul>
  
        <!-- <div class=" flex justify-center items-center h-px bg-slate-200 my-6 w-[117rem]"></div> -->
        <div class="flex justify-center items-center my-6">
                <div class="h-px bg-slate-200 w-[117rem]"></div>
        </div>

  
        <div class="flex justify-center">
          <ul class="flex items-center gap-5">
            <li><a href="#">រក្សាសិទ្ធិគ្រប់យ៉ាងដោយ៖រដ្ឋបាលខេត្តមានជ័យ</a></li>
          </ul>
        </div>
      </div>
    </footer>
  </template>
  

  <style scoped>
  /* Add any additional styles if necessary */
  </style>
  