<script setup>
   
</script>

   <template>
          <div class="flex flex-col justify-center items-center">
               <h1 class="text-center pt-12">សេចក្តីប្រកាសព័ត៌មាន</h1>
               <img src="/public/images/content/mocspace_1719388983279 1.png" alt="Image" class="w-[1780px] h-[877px] object-cover object-center pt-12 pb-5 rounded-sm">
          </div>
          <div>
               <Icon class="size-[32px] mt-[10rem]" icon="uil:setting"/>
          </div>
             
          <p class=" w-[100rem] pl-14 mb-20">
               
                    ដំណើរទស្សនកិច្ចសិក្សាទៅកាន់ខេត្តមណ្ឌលគិរី ក្នុងដំណើរការ ទស្សនកិច្ចនេះ និសិ្សតបានចុះកិច្ចសិក្សានិងប្រមូលព័ត៍មានដំណើរទស្សនកិច្ចសិក្សាទៅកាន់ខេត្តមណ្ឌលគិរី ក្នុងដំណើរការ ទស្សនកិច្ចនេះ និសិ្សតបានចុះកិច្ចសិក្សា និងប្រមូលព័ត៍មាន...
          </p>
          
   </template>
   
  
   <style scoped>
   /* Add any additional styles here if needed */
      h1{
          font-family: 'Khmer OS Muol';
          font-style: normal;
          font-weight: 300;
          font-size: xx-large;
      }
      p{
          font-family: 'Khmer OS Battambang';
          font-style: normal;
          font-weight: normal;
          font-size: xx-large;
      }
   </style>
   
