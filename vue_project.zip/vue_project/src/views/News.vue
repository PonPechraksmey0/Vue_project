<script setup>

</script>

<template>
    <h1>News page</h1>
</template>

<style>

</style>
