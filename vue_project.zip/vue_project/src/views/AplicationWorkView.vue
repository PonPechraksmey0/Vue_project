<script setup>

</script>

<template>
    <div>
            <h1 class="text-center pt-12">ព័ត៏មានថ្មីៗ</h1>
    </div>
</template>

<style scoped>
   h1{
          font-family: 'Khmer OS Muol';
          font-style: normal;
          font-weight: 300;
          font-size: xx-large;
      }
</style>